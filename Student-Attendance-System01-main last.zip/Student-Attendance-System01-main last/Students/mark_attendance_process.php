<?php
session_start();
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentId = $_POST['student_id'];
    $classId = $_POST['class_id'];
    // Add other attendance data retrieval here

    $status = '1'; // Assuming the student is present, modify as needed
    $dateTimeTaken = date('Y-m-d H:i:s'); // Assuming current date and time, modify as needed

    $query = "INSERT INTO tblattendance (admissionNo, classId, classArmId, sessionTermId, status, dateTimeTaken) 
              VALUES ('$studentId', '$classId', 'classArmId', 'sessionTermId', '$status', '$dateTimeTaken')";

    $result = mysqli_query($conn, $query);

    if ($result) {
        echo "Attendance marked successfully.";
    } else {
        echo "Error marking attendance.";
    }
} else {
    header('Location: mark_attendance.php');
    exit();
}
?>
