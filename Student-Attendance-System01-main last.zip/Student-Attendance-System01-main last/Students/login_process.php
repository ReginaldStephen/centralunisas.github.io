<?php
session_start();
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $admissionNumber = $_POST['admissionNumber'];
    $password = md5($_POST['password']); // Use appropriate hashing

    $query = "SELECT * FROM tblstudents WHERE admissionNumber = '$admissionNumber' AND password = '$password'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $student = mysqli_fetch_assoc($result);
        $_SESSION['student_id'] = $student['Id'];
        header('Location: mark_attendance.php');
        exit();
    } else {
        echo "Invalid login credentials.";
    }
} else {
    header('Location: login.php');
    exit();
}
?>
