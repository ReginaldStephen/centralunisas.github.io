<?php 
// Include the database connection file
include 'Includes/dbcon.php';
// Start a new session
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Meta tags for character set, compatibility, and viewport -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Meta tags for SEO description -->
    <meta name="description" content="">
    <meta name="author" content="">
    
    <!-- Favicon for the website -->
    <link href="img/logo/centralogo.png" rel="icon">
    
    <!-- Title of the webpage -->
    <title>Central University - Login</title>
    
    <!-- External CSS files -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/ruang-admin.min.css" rel="stylesheet">

</head>

<body class="bg-gradient-login" style="background-image: url('./img/logo/centralbackgroundimage.png');">
    <!-- Login Content -->
    <div class="container-login">
        <div class="row justify-content-center">
            <div class="col-xl-10 col-lg-12 col-md-9">
                <div class="card shadow-sm my-5">
                    <div class="card-body p-0">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="login-form">
                                    <!-- Header Section -->
                                    <h5 align="center">CENTRAL UNIVERSITY STUDENT ATTENDANCE SYSTEM</h5>
                                    <div class="text-center">
                                        <img src="img/logo/centralogo.png" style="width:100px;height:100px">
                                        <br><br>
                                        <h1 class="h4 text-gray-900 mb-4">Login Panel</h1>
                                    </div>
                                    
                                    <!-- Login Form -->
                                    <form class="user" method="Post" action="">
                                        <div class="form-group">
                                            <!-- User Type Dropdown -->
                                            <select required name="userType" class="form-control mb-3">
                                                <option value="">--Select User Roles--</option>
                                                <option value="Administrator">Administrator</option>
                                                <option value="ClassTeacher">Lecturer</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <!-- Username Input -->
                                            <input type="text" class="form-control" required name="username" id="exampleInputEmail" placeholder="Enter Email Address">
                                        </div>
                                        <div class="form-group">
                                            <!-- Password Input -->
                                            <input type="password" name="password" required class="form-control" id="exampleInputPassword" placeholder="Enter Password">
                                        </div>
                                        <div class="form-group">
                                            <div class="custom-control custom-checkbox small" style="line-height: 1.5rem;">
                                                <!-- Remember Me Checkbox (commented out) -->
                                                <!-- <input type="checkbox" class="custom-control-input" id="customCheck"> -->
                                                <!-- <label class="custom-control-label" for="customCheck">Remember Me</label> -->
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <!-- Login Button -->
                                            <input type="submit" class="btn btn-success btn-block" value="Login" name="login" />
                                        </div>
                                    </form>


                                    


<?php 
// Check if the login form is submitted
if(isset($_POST['login'])){
    // Collect form data
    $userType = $_POST['userType'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Encrypt the password using md5 (Note: md5 is not secure, consider using more robust hashing methods)
    $password = md5($password);

    // Check user type for login
    if($userType == "Administrator"){
        // Query to check administrator credentials
        $query = "SELECT * FROM tbladmin WHERE emailAddress = '$username' AND password = '$password'";
        $rs = $conn->query($query);
        $num = $rs->num_rows;
        $rows = $rs->fetch_assoc();

        if($num > 0){
            // Start a session and set session variables for administrator
            session_start();
            $_SESSION['userId'] = $rows['Id'];
            $_SESSION['firstName'] = $rows['firstName'];
            $_SESSION['lastName'] = $rows['lastName'];
            $_SESSION['emailAddress'] = $rows['emailAddress'];

            // Redirect to the administrator's dashboard
            echo "<script type = \"text/javascript\">
            window.location = (\"Admin/index.php\")
            </script>";
        } else {
            // Display an alert for invalid credentials
            echo "<div class='alert alert-danger' role='alert'>
            Invalid Username/Password!
            </div>";
        }
    } else if($userType == "ClassTeacher"){
        // Query to check class teacher credentials
        $query = "SELECT * FROM tblclassteacher WHERE emailAddress = '$username' AND password = '$password'";
        $rs = $conn->query($query);
        $num = $rs->num_rows;
        $rows = $rs->fetch_assoc();

        if($num > 0){
            // Start a session and set session variables for class teacher
            session_start();
            $_SESSION['userId'] = $rows['Id'];
            $_SESSION['firstName'] = $rows['firstName'];
            $_SESSION['lastName'] = $rows['lastName'];
            $_SESSION['emailAddress'] = $rows['emailAddress'];
            $_SESSION['classId'] = $rows['classId'];
            $_SESSION['classArmId'] = $rows['classArmId'];

            // Redirect to the class teacher's dashboard
            echo "<script type = \"text/javascript\">
            window.location = (\"ClassTeacher/index.php\")
            </script>";
        } else {
            // Display an alert for invalid credentials
            echo "<div class='alert alert-danger' role='alert'>
            Invalid Username/Password!
            </div>";
        }
    } else {
        // Display an alert for invalid user type
        echo "<div class='alert alert-danger' role='alert'>
        Invalid Username/Password!
        </div>";
    }
}
?>

<!-- HTML content for login page -->
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ... (unchanged) ... -->
</head>

<body class="bg-gradient-login" style="background-image: url('./img/logo/centralbackgroundimage.png');">
    <!-- Login Content -->
    <div class="container-login">
        <!-- ... (unchanged) ... -->
    </div>
    <!-- Login Content -->

    <!-- External JS files -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/ruang-admin.min.js"></script>
</body>

</html>


  