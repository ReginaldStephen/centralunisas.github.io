<?php
    // Database connection details
	$host = "localhost";             // Hostname where the MySQL server is running
	$user = "root";                  // MySQL username
	$pass = "";                      // MySQL password
	$db = "attendancemsystem";       // Database name
	
    // Establish a new MySQLi database connection
	$conn = new mysqli($host, $user, $pass, $db);

    // Check if the connection was successful
	if ($conn->connect_error) {
        // Display an error message if the connection failed
		echo "Seems like you have not configured the database. Failed To Connect to database:" . $conn->connect_error;
	}
?>
