<?php 
// Disable error reporting for production (set to 0 to suppress errors)
error_reporting(0);

// Include the 'dbcon.php' file to establish a database connection
include '../Includes/dbcon.php';

// Check if the form is submitted (form submission detection)
if(isset($_POST['submit'])){

    // Collect user input from the form using POST method
    $firstName = $_POST['firstName'];   // Get the value of the 'firstName' input field
    $lastName = $_POST['lastName'];     // Get the value of the 'lastName' input field
    $email = $_POST['email'];           // Get the value of the 'email' input field
    $phoneNo = $_POST['phoneNo'];       // Get the value of the 'phoneNo' input field
    $password = $_POST['password'];     // Get the value of the 'password' input field
    $conPassword = $_POST['conPassword']; // Get the value of the 'conPassword' input field
    $gender = $_POST['gender'];         // Get the value of the 'gender' input field
    $dob = $_POST['dob'];               // Get the value of the 'dob' input field
    $state = $_POST['state'];           // Get the value of the 'state' input field
    $city = $_POST['city'];             // Get the value of the 'city' input field
    $address = $_POST['address'];       // Get the value of the 'address' input field
    $lga = $_POST['lga'];               // Get the value of the 'lga' input field
    $coopAccountId = $_POST['coopAccountId']; // Get the value of the 'coopAccountId' input field
    $userType = $_POST['userType'];     // Get the value of the 'userType' input field

    // Get the current date and time for 'dateCreated'
    $dateCreated =  date("Y-m-d");




// echo $isLinked;
// echo $_POST['isExisting'];



// Select all records from the 'users' table where the emailAddress matches the provided email
$query = "SELECT * FROM users WHERE emailAddress = '$email'";
$rs = $conn->query($query);
$num = $rs->num_rows;

// Check if password and confirm password match
if($password != $conPassword)
{
    // Display an alert if passwords do not match and redirect to 'memberSetup.php'
    echo "<script type = \"text/javascript\">
    alert(\"Password Mismatch!\");
    window.location = (\"../memberSetup.php\")
    </script>";
}
else if($num > 0)
{
    // Display an alert if the email address has already been used and redirect to 'memberSetup.php'
    echo "<script type = \"text/javascript\">
    alert(\"Email Address has already been used!\");
    window.location = (\"../memberSetup.php\")
    </script>";
}
else
{
    // Check the user type to determine the type of user to be created
    if($_POST['userType'] == 1) // if the userType is staff, save staff info and user info
    {
        // Collect additional data for staff type user
        $companyId = $_POST['companyId'];
        $staffCode = $_POST['staffCode'];
        $position = $_POST['position'];
        $level = $_POST['level'];
        $department = $_POST['department'];
        $description = $_POST['description'];

        // Insert user information into the 'users' table
        $userqr = "INSERT INTO users (roleId,coopId,firstName,lastName,gender,dob,city,state,lga,emailAddress,address,phoneNo,password,dateCreated) 
                VALUES ('2','$coopAccountId','$firstName','$lastName','$gender','$dob','$city','$state','$lga','$email','$address','$phoneNo','$password','$dateCreated')";
        $useres = $conn->query($userqr);

        // Check if user information was inserted successfully
        if($useres === TRUE)
        {
            // Check if the staff with staff code already exists
            $qryss = "SELECT * FROM companystaff WHERE compId = '$companyId' AND staffCode = '$staffCode'";
            $rst = $conn->query($qryss);
            $num = $rst->num_rows;

            // If staff with staff code does not exist, proceed to insert staff information
            if($num == 0)
            {
                // Get the user ID for the newly inserted user
                $querys = "SELECT * FROM users WHERE emailAddress = '$email'";
                $rslt = $conn->query($querys);
                $rrw = $rslt->fetch_assoc();
                $memberId = $rrw['Id'];

                // Insert staff information into the 'companystaff' table
                $compqr = "INSERT INTO companystaff (staffCode,memberId,compId,coopId,position,level,department,jobDescription,dateCreated) 
                    VALUES ('$staffCode','$memberId','$companyId','$coopAccountId','$position','$level','$department','$description','$dateCreated')";
                $compres = $conn->query($compqr);

                // Check if staff information was inserted successfully
                if($compres === TRUE)
                {
                    // Do nothing (you may add additional actions here if needed)
                }
                else
                {
                    // Display an alert if an error occurred during staff information insertion
                    echo "<script type = \"text/javascript\">
                    alert(\"An Error Occurred!\");
                    </script>";
                }

                // Display an alert for successful creation and redirect to 'index.php'
                echo "<script type = \"text/javascript\">
                alert(\"Created Successfully!\");
                window.location = (\"../index.php\")
                </script>";
            }
            else
            {
                // Display an alert if staff with staff code already exists and redirect to 'memberSetup.php'
                echo "<script type = \"text/javascript\">
                alert(\"Staff with staff code already exist!\");
                window.location = (\"../memberSetup.php\")
                </script>";
            }
        }
        else
        {
            // Display an alert if an error occurred during user information insertion
            echo "<script type = \"text/javascript\">
            alert(\"An Error Occurred!\");
            </script>";
        }
    }

    else if($_POST['userType'] == 2) // if the userType is ExternalMmber, save the member info to the user table only
    {
        // Insert user information into the 'users' table for External Member type
        $userqr = "INSERT INTO users (roleId,coopId,firstName,lastName,gender,dob,city,state,lga,emailAddress,address,phoneNo,password,dateCreated) 
                VALUES ('2','$coopAccountId','$firstName','$lastName','$gender','$dob','$city','$state','$lga','$email','$address','$phoneNo','$password','$dateCreated')";
        $useres = $conn->query($userqr);

        // Check if user information was inserted successfully
        if($useres === TRUE)
        {
            // Do nothing (you may add additional actions here if needed)
        }
        else
        {
            // Display an alert if an error occurred during user information insertion
            echo "<script type = \"text/javascript\">
            alert(\"An Error Occurred!\");
            </script>";
        }

        // Display an alert for successful creation and redirect to 'index.php'
        echo "<script type = \"text/javascript\">
        alert(\"Created Successfully!\");
        window.location = (\"../index.php\")
        </script>";
    }

} // end of else statement

} //end of if for submit button

?>




