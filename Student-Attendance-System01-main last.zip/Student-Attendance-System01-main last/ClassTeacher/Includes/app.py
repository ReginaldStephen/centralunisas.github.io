from flask import Flask, render_template, request, redirect, url_for
import mysql.connector
import qrcode

app = Flask(__name__)

def get_mysql_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='',
        database='attendancemsystem'
    )

def create_attendance_table():
    conn = get_mysql_connection()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tblattendance (
            id INT AUTO_INCREMENT PRIMARY KEY,
            admissionNumber VARCHAR(255) NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

create_attendance_table()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate_qr', methods=['POST'])
def generate_qr():
    admissionNumber = request.form['admissionNumber']

    # Insert attendance data into the MySQL database
    conn = get_mysql_connection()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO tblattendance (admissionNumber) VALUES (%s)', (admissionNumber,))
    conn.commit()
    conn.close()

    # Generate a QR code with the admission number
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(admissionNumber)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")

    # Save the QR code image
    img.save('static/qrcode.png')

    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
