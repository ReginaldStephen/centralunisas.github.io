<?php
// Include the database connection file
include '../Includes/dbcon.php';

// Get the class ID from the query string and convert it to an integer
$cid = intval($_GET['cid']);

// Execute a query to select class arms based on the provided class ID
$queryss = mysqli_query($conn, "SELECT * FROM tblclassarms WHERE classId=" . $cid);

// Get the number of rows returned by the query
$countt = mysqli_num_rows($queryss);

// Output a <select> dropdown in HTML with options based on the query results
echo '
<select required name="classArmId" class="form-control mb-3">';
echo '<option value="">--Select Class Arm--</option>';

// Loop through each row of the query result
while ($row = mysqli_fetch_array($queryss)) {
    // Output an option for each class arm with its 'Id' as the value and 'classArmName' as the displayed text
    echo '<option value="' . $row['Id'] . '" >' . $row['classArmName'] . '</option>';
}

// End the <select> dropdown element
echo '</select>';
?>
